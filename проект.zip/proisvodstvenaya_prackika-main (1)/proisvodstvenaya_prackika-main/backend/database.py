# backend/database.py
import sqlite3
from datetime import datetime
import json

def init_database():
    """Инициализация базы данных"""
    conn = sqlite3.connect('metrics.db')
    cursor = conn.cursor()
    
    # Удаляем старую таблицу для пересоздания с новыми полями
    cursor.execute('DROP TABLE IF EXISTS websites')
    cursor.execute('DROP TABLE IF EXISTS website_history')
    cursor.execute('DROP TABLE IF EXISTS reports')
    
    # Таблица для сайтов
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS websites (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        url TEXT NOT NULL,
        domain TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        
        -- Основная информация
        title TEXT,
        meta_description TEXT,
        status_code INTEGER,
        
        -- PageSpeed метрики
        performance_score INTEGER,
        accessibility_score INTEGER,
        best_practices_score INTEGER,
        seo_score INTEGER,
        overall_score INTEGER,
        security_score INTEGER DEFAULT 0,
        
        -- Core Web Vitals
        first_contentful_paint REAL,
        largest_contentful_paint REAL,
        cumulative_layout_shift REAL,
        total_blocking_time REAL,
        speed_index REAL,
        time_to_interactive REAL,
        
        -- Дополнительные метрики
        page_size_kb INTEGER,
        load_time_ms INTEGER,
        requests_count INTEGER,
        transfer_size_kb INTEGER,
        
        -- SEO метрики
        h1_count INTEGER DEFAULT 0,
        h2_count INTEGER DEFAULT 0,
        images_count INTEGER DEFAULT 0,
        images_without_alt INTEGER DEFAULT 0,
        internal_links INTEGER DEFAULT 0,
        external_links INTEGER DEFAULT 0,
        word_count INTEGER DEFAULT 0,
        
        -- Технические параметры
        has_ssl BOOLEAN DEFAULT FALSE,
        has_robots_txt BOOLEAN DEFAULT FALSE,
        has_sitemap BOOLEAN DEFAULT FALSE,
        response_time_ms INTEGER,
        
        -- Статусы
        needs_optimization BOOLEAN DEFAULT FALSE,
        status_color TEXT DEFAULT 'gray',
        
        -- Для отчетов
        notes TEXT,
        recommendations TEXT
    )
    ''')
    
    # Таблица истории изменений
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS website_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        website_id INTEGER NOT NULL,
        checked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        performance_score INTEGER,
        seo_score INTEGER,
        overall_score INTEGER,
        page_size_kb INTEGER,
        load_time_ms INTEGER,
        
        FOREIGN KEY (website_id) REFERENCES websites(id) ON DELETE CASCADE
    )
    ''')
    
    # Таблица отчетов
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS reports (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        website_id INTEGER NOT NULL,
        generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        report_type TEXT,
        content TEXT,
        sent_to_email TEXT,
        sent_at TIMESTAMP,
        
        FOREIGN KEY (website_id) REFERENCES websites(id) ON DELETE CASCADE
    )
    ''')
    
    # Индексы для оптимизации
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_websites_domain ON websites(domain)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_websites_created_at ON websites(created_at)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_history_website_id ON website_history(website_id)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_reports_website_id ON reports(website_id)')
    
    conn.commit()
    conn.close()
    
    print("✅ База данных инициализирована")

def get_connection():
    """Получить соединение с БД"""
    return sqlite3.connect('metrics.db', check_same_thread=False)

def add_website_analysis(data):
    """Добавить анализ сайта в БД"""
    conn = get_connection()
    cursor = conn.cursor()
    
    try:
        print(f"💾 Сохранение в БД: {data.get('url', 'Unknown')}")
        
        # Проверяем, есть ли уже такой URL в базе
        cursor.execute('SELECT id FROM websites WHERE url = ?', (data['url'],))
        existing = cursor.fetchone()
        
        if existing:
            print(f"🔄 Обновление существующей записи ID: {existing[0]}")
            website_id = existing[0]
            
            # Обновляем существующую запись
            cursor.execute('''
                UPDATE websites SET
                    title = ?, meta_description = ?, status_code = ?,
                    performance_score = ?, accessibility_score = ?, best_practices_score = ?, 
                    seo_score = ?, overall_score = ?, security_score = ?,
                    first_contentful_paint = ?, largest_contentful_paint = ?, cumulative_layout_shift = ?,
                    total_blocking_time = ?, speed_index = ?, time_to_interactive = ?,
                    page_size_kb = ?, load_time_ms = ?, requests_count = ?, transfer_size_kb = ?,
                    h1_count = ?, h2_count = ?, images_count = ?, images_without_alt = ?,
                    internal_links = ?, external_links = ?, word_count = ?,
                    has_ssl = ?, has_robots_txt = ?, has_sitemap = ?, response_time_ms = ?,
                    needs_optimization = ?, status_color = ?, notes = ?, recommendations = ?,
                    created_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ''', (
                data.get('title'), data.get('meta_description'), data.get('status_code'),
                data.get('performance_score'), data.get('accessibility_score'), data.get('best_practices_score'), 
                data.get('seo_score'), data.get('overall_score'), data.get('security_score', 0),
                data.get('first_contentful_paint'), data.get('largest_contentful_paint'), data.get('cumulative_layout_shift'),
                data.get('total_blocking_time'), data.get('speed_index'), data.get('time_to_interactive'),
                data.get('page_size_kb'), data.get('load_time_ms'), data.get('requests_count'), data.get('transfer_size_kb'),
                data.get('h1_count'), data.get('h2_count'), data.get('images_count'), data.get('images_without_alt'),
                data.get('internal_links'), data.get('external_links'), data.get('word_count'),
                data.get('has_ssl', False), data.get('has_robots_txt', False), data.get('has_sitemap', False), 
                data.get('response_time_ms'),
                data.get('needs_optimization', False), data.get('status_color', 'gray'),
                data.get('notes'), data.get('recommendations'),
                website_id
            ))
        else:
            print(f"➕ Создание новой записи")
            # Вставляем новую запись
            cursor.execute('''
                INSERT INTO websites (
                    url, domain, title, meta_description, status_code,
                    performance_score, accessibility_score, best_practices_score, seo_score, overall_score, security_score,
                    first_contentful_paint, largest_contentful_paint, cumulative_layout_shift, 
                    total_blocking_time, speed_index, time_to_interactive,
                    page_size_kb, load_time_ms, requests_count, transfer_size_kb,
                    h1_count, h2_count, images_count, images_without_alt,
                    internal_links, external_links, word_count,
                    has_ssl, has_robots_txt, has_sitemap, response_time_ms,
                    needs_optimization, status_color, notes, recommendations
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                data['url'], data.get('domain', ''), data.get('title'), data.get('meta_description'), data.get('status_code'),
                data.get('performance_score'), data.get('accessibility_score'), data.get('best_practices_score'), 
                data.get('seo_score'), data.get('overall_score'), data.get('security_score', 0),
                data.get('first_contentful_paint'), data.get('largest_contentful_paint'), data.get('cumulative_layout_shift'),
                data.get('total_blocking_time'), data.get('speed_index'), data.get('time_to_interactive'),
                data.get('page_size_kb'), data.get('load_time_ms'), data.get('requests_count'), data.get('transfer_size_kb'),
                data.get('h1_count'), data.get('h2_count'), data.get('images_count'), data.get('images_without_alt'),
                data.get('internal_links'), data.get('external_links'), data.get('word_count'),
                data.get('has_ssl', False), data.get('has_robots_txt', False), data.get('has_sitemap', False), 
                data.get('response_time_ms'),
                data.get('needs_optimization', False), data.get('status_color', 'gray'),
                data.get('notes'), data.get('recommendations')
            ))
            
            website_id = cursor.lastrowid
        
        # Добавляем в историю
        cursor.execute('''
            INSERT INTO website_history (website_id, performance_score, seo_score, overall_score, page_size_kb, load_time_ms)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (website_id, data.get('performance_score'), data.get('seo_score'), data.get('overall_score'),
              data.get('page_size_kb'), data.get('load_time_ms')))
        
        conn.commit()
        print(f"✅ Данные сохранены в БД, ID: {website_id}")
        
        return website_id
        
    except Exception as e:
        conn.rollback()
        print(f"❌ Ошибка сохранения в БД: {e}")
        raise e
    finally:
        conn.close()

def get_all_websites(limit=50, offset=0):
    """Получить все анализы"""
    conn = get_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            SELECT *, 
                CASE 
                    WHEN overall_score >= 80 THEN 'green'
                    WHEN overall_score >= 60 THEN 'yellow'
                    WHEN overall_score >= 40 THEN 'orange'
                    ELSE 'red'
                END as calculated_status_color
            FROM websites 
            ORDER BY created_at DESC 
            LIMIT ? OFFSET ?
        ''', (limit, offset))
        
        columns = [description[0] for description in cursor.description]
        websites = []
        
        for row in cursor.fetchall():
            website = dict(zip(columns, row))
            # Преобразуем типы данных
            website['has_ssl'] = bool(website['has_ssl'])
            website['has_robots_txt'] = bool(website['has_robots_txt'])
            website['has_sitemap'] = bool(website['has_sitemap'])
            website['needs_optimization'] = bool(website['needs_optimization'])
            websites.append(website)
        
        print(f"📊 Получено {len(websites)} записей из БД")
        return websites
        
    except Exception as e:
        print(f"❌ Ошибка получения данных: {e}")
        return []
    finally:
        conn.close()

def get_website_by_id(website_id):
    """Получить анализ по ID"""
    conn = get_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('SELECT * FROM websites WHERE id = ?', (website_id,))
        
        columns = [description[0] for description in cursor.description]
        row = cursor.fetchone()
        
        if row:
            website = dict(zip(columns, row))
            # Преобразуем типы данных
            website['has_ssl'] = bool(website['has_ssl'])
            website['has_robots_txt'] = bool(website['has_robots_txt'])
            website['has_sitemap'] = bool(website['has_sitemap'])
            website['needs_optimization'] = bool(website['needs_optimization'])
            
            print(f"📄 Получена запись ID: {website_id}")
            return website
        
        print(f"⚠️ Запись ID: {website_id} не найдена")
        return None
        
    except Exception as e:
        print(f"❌ Ошибка получения записи: {e}")
        return None
    finally:
        conn.close()

def get_website_history(website_id):
    """Получить историю изменений сайта"""
    conn = get_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            SELECT * FROM website_history 
            WHERE website_id = ? 
            ORDER BY checked_at DESC
        ''', (website_id,))
        
        columns = [description[0] for description in cursor.description]
        history = []
        
        for row in cursor.fetchall():
            history.append(dict(zip(columns, row)))
        
        print(f"📈 Получено {len(history)} записей истории для ID: {website_id}")
        return history
        
    except Exception as e:
        print(f"❌ Ошибка получения истории: {e}")
        return []
    finally:
        conn.close()

def delete_website(website_id):
    """Удалить анализ сайта"""
    conn = get_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('DELETE FROM websites WHERE id = ?', (website_id,))
        conn.commit()
        
        deleted = cursor.rowcount > 0
        if deleted:
            print(f"🗑️ Удалена запись ID: {website_id}")
        else:
            print(f"⚠️ Запись ID: {website_id} не найдена для удаления")
        
        return deleted
        
    except Exception as e:
        conn.rollback()
        print(f"❌ Ошибка удаления: {e}")
        return False
    finally:
        conn.close()

def get_statistics():
    """Получить статистику"""
    conn = get_connection()
    cursor = conn.cursor()
    
    try:
        # Общее количество
        cursor.execute('SELECT COUNT(*) FROM websites')
        total = cursor.fetchone()[0] or 0
        
        # Средние оценки
        cursor.execute('''
            SELECT 
                ROUND(AVG(overall_score), 1) as avg_overall,
                ROUND(AVG(performance_score), 1) as avg_performance,
                ROUND(AVG(seo_score), 1) as avg_seo,
                ROUND(AVG(accessibility_score), 1) as avg_accessibility
            FROM websites
            WHERE overall_score IS NOT NULL
        ''')
        stats = cursor.fetchone()
        
        # Количество сайтов по статусу
        cursor.execute('''
            SELECT 
                SUM(CASE WHEN overall_score >= 80 THEN 1 ELSE 0 END) as excellent,
                SUM(CASE WHEN overall_score >= 60 AND overall_score < 80 THEN 1 ELSE 0 END) as good,
                SUM(CASE WHEN overall_score >= 40 AND overall_score < 60 THEN 1 ELSE 0 END) as poor,
                SUM(CASE WHEN overall_score < 40 OR overall_score IS NULL THEN 1 ELSE 0 END) as bad
            FROM websites
        ''')
        status_stats = cursor.fetchone()
        
        print(f"📊 Статистика: {total} записей в БД")
        
        return {
            'total': total,
            'avg_overall': stats[0] or 0,
            'avg_performance': stats[1] or 0,
            'avg_seo': stats[2] or 0,
            'avg_accessibility': stats[3] or 0,
            'excellent': status_stats[0] or 0,
            'good': status_stats[1] or 0,
            'poor': status_stats[2] or 0,
            'bad': status_stats[3] or 0
        }
        
    except Exception as e:
        print(f"❌ Ошибка получения статистики: {e}")
        return {
            'total': 0,
            'avg_overall': 0,
            'avg_performance': 0,
            'avg_seo': 0,
            'avg_accessibility': 0,
            'excellent': 0,
            'good': 0,
            'poor': 0,
            'bad': 0
        }
    finally:
        conn.close()

def get_database_info():
    """Получить информацию о БД"""
    conn = get_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()
        
        info = {}
        for table in tables:
            table_name = table[0]
            cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
            count = cursor.fetchone()[0]
            info[table_name] = count
        
        print(f"📁 Информация о БД: {info}")
        return info
        
    except Exception as e:
        print(f"❌ Ошибка получения информации о БД: {e}")
        return {}
    finally:
        conn.close()

# Инициализация БД при импорте
init_database()
get_database_info()