import os
import sys
import subprocess

def check_and_install_dependencies():
    """Проверяет и устанавливает зависимости"""
    dependencies = [
        'fastapi',
        'uvicorn', 
        'sqlalchemy',
        'aiohttp',
        'beautifulsoup4',
        'pydantic',
        'aiosqlite',
        'jinja2'
    ]
    
    print("🔍 Проверка зависимостей...")
    for dep in dependencies:
        try:
            __import__(dep.replace('-', '_'))
            print(f"✅ {dep} установлен")
        except ImportError:
            print(f"📦 Устанавливаю {dep}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", dep])

def main():
    """Основная функция запуска"""
    print("=" * 50)
    print("🌐 WEBSITE ANALYZER SERVER")
    print("=" * 50)
    
    # Проверяем и устанавливаем зависимости
    check_and_install_dependencies()
    
    print("\n🚀 Запуск сервера...")
    print("📡 Адреса сервера:")
    print("   - http://127.0.0.1:8000")
    print("   - http://localhost:8000")
    print("\n📚 Документация API:")
    print("   - http://127.0.0.1:8000/docs")
    print("   - http://localhost:8000/docs")
    print("\n🖥️  Веб-интерфейс:")
    print("   - http://127.0.0.1:8000")
    print("=" * 50)
    print("\nДля остановки сервера нажмите Ctrl+C\n")
    
    # Запускаем сервер
    os.system("python -m uvicorn main:app --host 127.0.0.1 --port 8000 --reload")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n👋 Сервер остановлен")
    except Exception as e:
        print(f"\n❌ Ошибка: {e}")  