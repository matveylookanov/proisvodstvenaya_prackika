import aiohttp
from bs4 import BeautifulSoup
from urllib.parse import urlparse
import time
import asyncio
import ssl
from typing import Dict, Any


class WebsiteAnalyzer:
    def __init__(self):
        self.timeout = aiohttp.ClientTimeout(total=30, connect=10)
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
    
    async def analyze(self, url: str) -> Dict[str, Any]:
        """Основной метод анализа сайта"""
        print(f"🔍 Начинаю анализ: {url}")
        
        # Нормализуем URL
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        
        parsed_url = urlparse(url)
        domain = parsed_url.netloc
        
        try:
            # Инициализируем результат с базовыми данными
            result = {
                "url": url,
                "domain": domain,
                "title": "",
                "meta_description": "",
                "status_code": 0,
                "error": None,
                "analysis_time": time.time()
            }
            
            # SSL контекст
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            
            connector = aiohttp.TCPConnector(ssl=ssl_context)
            
            async with aiohttp.ClientSession(
                timeout=self.timeout, 
                connector=connector,
                headers=self.headers
            ) as session:
                
                # 1. Базовый запрос
                try:
                    start_time = time.time()
                    async with session.get(url, allow_redirects=True, max_redirects=5) as response:
                        response_time = time.time() - start_time
                        html = await response.text()
                        
                        result["status_code"] = response.status
                        result["response_time_ms"] = int(response_time * 1000)
                        result["response_size"] = len(html)
                        result["page_size_kb"] = len(html.encode('utf-8')) / 1024
                        
                        # Парсим HTML
                        soup = BeautifulSoup(html, 'html.parser')
                        
                        # Заголовок
                        title_tag = soup.find('title')
                        if title_tag:
                            result["title"] = title_tag.text.strip()[:500]
                        
                        # Meta description
                        meta_desc = soup.find('meta', attrs={'name': 'description'})
                        if meta_desc and meta_desc.get('content'):
                            result["meta_description"] = meta_desc.get('content')[:1000]
                        
                        # Подсчет слов
                        text = soup.get_text()
                        words = [word for word in text.split() if word.strip()]
                        result["word_count"] = len(words)
                        
                        # SEO метрики
                        result["h1_count"] = len(soup.find_all('h1'))
                        result["h2_count"] = len(soup.find_all('h2'))
                        result["h3_count"] = len(soup.find_all('h3'))
                        
                        # Ссылки
                        links = soup.find_all('a', href=True)
                        internal_links = 0
                        external_links = 0
                        
                        for link in links:
                            href = link.get('href', '').strip()
                            if not href:
                                continue
                            
                            if href.startswith('#'):
                                continue
                            
                            if href.startswith(('http://', 'https://')):
                                link_domain = urlparse(href).netloc
                                if link_domain == domain or link_domain.endswith(f'.{domain}'):
                                    internal_links += 1
                                else:
                                    external_links += 1
                            else:
                                internal_links += 1
                        
                        result["internal_links"] = internal_links
                        result["external_links"] = external_links
                        
                        # Изображения
                        images = soup.find_all('img')
                        result["images_count"] = len(images)
                        result["images_without_alt"] = sum(1 for img in images if not img.get('alt'))
                        
                        # Проверка SSL
                        result["has_ssl"] = url.startswith('https://')
                        
                        # Проверка robots.txt
                        result["has_robots_txt"] = await self._check_file_exists(session, f"{parsed_url.scheme}://{domain}/robots.txt")
                        
                        # Проверка sitemap.xml
                        result["has_sitemap"] = await self._check_file_exists(session, f"{parsed_url.scheme}://{domain}/sitemap.xml")
                        
                        # Расчет оценок
                        scores = self._calculate_scores(result)
                        result.update(scores)
                        
                        # Рекомендации
                        result["recommendations"] = self._generate_recommendations(result, scores)
                        
                        print(f"✅ Анализ завершен: {domain}")
                        return result
                        
                except aiohttp.ClientError as e:
                    result["error"] = f"Ошибка сети: {str(e)}"
                    print(f"❌ Сетевая ошибка для {url}: {e}")
                    
                except asyncio.TimeoutError:
                    result["error"] = "Таймаут при анализе сайта"
                    print(f"❌ Таймаут для {url}")
                    
                except Exception as e:
                    result["error"] = f"Ошибка анализа: {str(e)}"
                    print(f"❌ Ошибка анализа {url}: {e}")
            
            # Если дошли сюда, значит была ошибка, но возвращаем базовые данные
            if not result.get("error"):
                result["error"] = "Неизвестная ошибка анализа"
            
            # Все равно рассчитываем минимальные оценки
            scores = self._calculate_scores(result)
            result.update(scores)
            
            return result
            
        except Exception as e:
            print(f"❌ Критическая ошибка анализа {url}: {e}")
            return self._get_error_result(url, str(e))
    
    async def _check_file_exists(self, session, url: str) -> bool:
        """Проверяет существование файла на сервере"""
        try:
            async with session.head(url, timeout=5) as response:
                return response.status == 200
        except:
            return False
    
    def _calculate_scores(self, data: Dict) -> Dict[str, int]:
        """Рассчитывает оценки"""
        # Производительность (0-100)
        perf_score = 50
        
        if data.get("response_time_ms", 0) < 2000:
            perf_score += 30
        elif data.get("response_time_ms", 0) < 5000:
            perf_score += 15
        
        if data.get("page_size_kb", 0) < 500:
            perf_score += 20
        elif data.get("page_size_kb", 0) < 1500:
            perf_score += 10
        
        # SEO оценка (0-100)
        seo_score = 50
        
        if data.get("title"):
            seo_score += 10
        if data.get("meta_description"):
            seo_score += 10
        if data.get("h1_count", 0) >= 1:
            seo_score += 10
        if data.get("images_without_alt", 0) == 0:
            seo_score += 10
        if data.get("word_count", 0) > 300:
            seo_score += 10
        if data.get("internal_links", 0) > 10:
            seo_score += 10
        
        # Безопасность (0-100)
        security_score = 50
        if data.get("has_ssl"):
            security_score += 30
        if data.get("has_robots_txt"):
            security_score += 10
        if data.get("has_sitemap"):
            security_score += 10
        
        # Доступность (0-100)
        accessibility_score = 70
        if data.get("h1_count", 0) == 1:
            accessibility_score += 10
        if data.get("images_without_alt", 0) == 0:
            accessibility_score += 10
        if data.get("status_code", 0) == 200:
            accessibility_score += 10
        
        # Общая оценка
        overall_score = int((perf_score + seo_score + security_score + accessibility_score) / 4)
        
        # Статус
        status_color = "green"
        needs_optimization = False
        
        if overall_score >= 80:
            status_color = "green"
        elif overall_score >= 60:
            status_color = "yellow"
        elif overall_score >= 40:
            status_color = "orange"
            needs_optimization = True
        else:
            status_color = "red"
            needs_optimization = True
        
        return {
            "performance_score": min(max(perf_score, 0), 100),
            "seo_score": min(max(seo_score, 0), 100),
            "security_score": min(max(security_score, 0), 100),
            "accessibility_score": min(max(accessibility_score, 0), 100),
            "best_practices_score": min(max((perf_score + seo_score) // 2, 0), 100),
            "overall_score": overall_score,
            "status_color": status_color,
            "needs_optimization": needs_optimization
        }
    
    def _generate_recommendations(self, data: Dict, scores: Dict) -> str:
        """Генерация рекомендаций"""
        recommendations = []
        
        if scores.get("performance_score", 0) < 70:
            recommendations.append("Оптимизировать скорость загрузки страницы")
        
        if scores.get("seo_score", 0) < 70:
            recommendations.append("Улучшить SEO-оптимизацию")
        
        if not data.get("has_ssl", False):
            recommendations.append("Установить SSL-сертификат")
        
        if data.get("images_without_alt", 0) > 0:
            recommendations.append(f"Добавить alt-тексты к {data.get('images_without_alt')} изображениям")
        
        if not data.get("has_robots_txt", False):
            recommendations.append("Создать файл robots.txt")
        
        if not data.get("has_sitemap", False):
            recommendations.append("Создать карту сайта sitemap.xml")
        
        if data.get("h1_count", 0) == 0:
            recommendations.append("Добавить заголовок H1")
        elif data.get("h1_count", 0) > 1:
            recommendations.append("Использовать только один заголовок H1 на странице")
        
        if data.get("word_count", 0) < 300:
            recommendations.append("Увеличить объем текстового контента")
        
        return "; ".join(recommendations) if recommendations else "Сайт хорошо оптимизирован"
    
    def _get_error_result(self, url: str, error: str) -> Dict[str, Any]:
        """Возвращает результат при ошибке"""
        parsed_url = urlparse(url)
        domain = parsed_url.netloc if parsed_url.netloc else url
        
        return {
            "url": url,
            "domain": domain,
            "error": error,
            "title": "",
            "meta_description": "",
            "status_code": 0,
            "performance_score": 0,
            "seo_score": 0,
            "security_score": 0,
            "accessibility_score": 0,
            "best_practices_score": 0,
            "overall_score": 0,
            "status_color": "red",
            "needs_optimization": True,
            "recommendations": f"Ошибка анализа: {error}. Проверьте доступность сайта.",
            "response_time_ms": 0,
            "page_size_kb": 0,
            "word_count": 0,
            "h1_count": 0,
            "h2_count": 0,
            "internal_links": 0,
            "external_links": 0,
            "images_count": 0,
            "images_without_alt": 0,
            "has_ssl": False,
            "has_robots_txt": False,
            "has_sitemap": False
        }


# Создаем экземпляр анализатора
analyzer = WebsiteAnalyzer()

async def analyze_website(url: str) -> Dict[str, Any]:
    """Асинхронная функция анализа сайта (для импорта)"""
    return await analyzer.analyze(url)