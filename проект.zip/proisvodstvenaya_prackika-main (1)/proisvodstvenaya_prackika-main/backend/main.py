# backend/main.py
from fastapi import FastAPI, HTTPException, BackgroundTasks, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import os
import sys
import asyncio
import json


# Добавляем путь к текущей директории
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)

try:
    from database import init_database, add_website_analysis, get_all_websites, get_website_by_id, delete_website, get_statistics
    from website_analyzer import analyze_website as analyze_website_func
    print("✅ Модули загружены успешно")
except ImportError as e:
    print(f"❌ Ошибка импорта модулей: {e}")
    import subprocess
    print("Устанавливаем недостающие зависимости...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "aiohttp", "beautifulsoup4"])
    
    from database import init_database, add_website_analysis, get_all_websites, get_website_by_id, delete_website, get_statistics
    from website_analyzer import analyze_website as analyze_website_func

app = FastAPI(
    title="Website Analyzer API",
    description="API для анализа веб-сайтов",
    version="1.1.0"
)

# CORS - разрешаем все источники
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Разрешаем все для разработки
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Инициализация БД
init_database()
print("✅ База данных инициализирована")

# Статические файлы фронтенда
frontend_path = os.path.join(current_dir, "..", "frontend")
if os.path.exists(frontend_path):
    app.mount("/static", StaticFiles(directory=frontend_path), name="static")
    print(f"✅ Frontend найден: {frontend_path}")
else:
    print(f"⚠️ Frontend не найден: {frontend_path}")

# Модели Pydantic
class AnalysisRequest(BaseModel):
    url: str

# Хранилище для задач анализа
analysis_tasks = {}

# API Endpoints
@app.get("/")
async def serve_frontend():
    """Отдаем фронтенд"""
    frontend_file = os.path.join(frontend_path, "index.html")
    if os.path.exists(frontend_file):
        return FileResponse(frontend_file)
    return {"message": "Frontend not found"}

@app.get("/api")
async def api_root():
    """Корневой эндпоинт API"""
    return {
        "service": "Website Analyzer API",
        "version": "1.1.0",
        "endpoints": {
            "health": "/api/health (GET)",
            "analyze": "/api/analyze (POST)",
            "websites": "/api/websites (GET)",
            "website_detail": "/api/websites/{id} (GET)",
            "delete_website": "/api/websites/{id} (DELETE)",
            "statistics": "/api/statistics (GET)"
        }
    }

@app.get("/test")
async def test():
    """Тестовый эндпоинт для проверки работы API"""
    return {"message": "API работает", "status": "ok"}

@app.get("/api/test")
async def api_test():
    """Тестовый эндпоинт для API"""
    return {"message": "API endpoint работает", "status": "ok"}

@app.get("/api/health")
async def health_check():
    """Проверка состояния сервера"""
    return {
        "status": "ok",
        "service": "website-analyzer",
        "timestamp": asyncio.get_event_loop().time()
    }

@app.post("/api/analyze")
async def analyze_website(request: AnalysisRequest, background_tasks: BackgroundTasks):
    """Анализ сайта с улучшенной обработкой"""
    url = request.url.strip()

    if not url:
        raise HTTPException(status_code=400, detail="URL не может быть пустым")
    
    # Создаем ID задачи
    task_id = f"task_{int(asyncio.get_event_loop().time() * 1000)}"
    
    # Инициализируем задачу
    analysis_tasks[task_id] = {
        "status": "processing",
        "progress": 0,
        "url": url,
        "result": None,
        "error": None,
        "started_at": asyncio.get_event_loop().time()
    }
    
    # Запускаем анализ в фоне
    background_tasks.add_task(run_analysis, task_id, url)
    
    return {
        "status": "started",
        "task_id": task_id,
        "message": "Анализ начат",
        "url": url,
        "check_status": f"/api/analysis/{task_id}/status"
    }

@app.get("/api/analysis/{task_id}/status")
async def get_analysis_status(task_id: str):
    """Получение статуса анализа"""
    if task_id not in analysis_tasks:
        raise HTTPException(status_code=404, detail="Задача не найдена")
    
    task = analysis_tasks[task_id]
    
    if task["status"] == "completed":
        # Очищаем старые задачи (старше 5 минут)
        current_time = asyncio.get_event_loop().time()
        for tid in list(analysis_tasks.keys()):
            if current_time - analysis_tasks[tid].get("started_at", 0) > 300:  # 5 минут
                del analysis_tasks[tid]
    
    return {
        "task_id": task_id,
        "status": task["status"],
        "progress": task["progress"],
        "url": task["url"],
        "has_result": task["result"] is not None,
        "has_error": task["error"] is not None,
        "result_ready": task["status"] == "completed"
    }

@app.get("/api/analysis/{task_id}/result")
async def get_analysis_result(task_id: str):
    """Получение результата анализа"""
    if task_id not in analysis_tasks:
        raise HTTPException(status_code=404, detail="Задача не найдена")
    
    task = analysis_tasks[task_id]
    
    if task["status"] != "completed":
        raise HTTPException(status_code=425, detail="Анализ еще не завершен")
    
    if task["error"]:
        raise HTTPException(status_code=500, detail=task["error"])
    
    return {
        "status": "success",
        "task_id": task_id,
        "data": task["result"]
    }

async def run_analysis(task_id: str, url: str):
    """Запуск анализа в фоне с обновлением прогресса"""
    try:
        # Этап 1: Подготовка
        analysis_tasks[task_id]["progress"] = 10
        await asyncio.sleep(0.1)
        
        # Этап 2: Получение данных
        analysis_tasks[task_id]["progress"] = 30
        await asyncio.sleep(0.1)
        
        # Этап 3: Анализ сайта
        analysis_tasks[task_id]["progress"] = 50
        result = await analyze_website_func(url)
        
        # Этап 4: Сохранение в БД
        analysis_tasks[task_id]["progress"] = 80
        
        if "error" not in result or not result["error"]:
            try:
                # Сохраняем в БД
                website_id = add_website_analysis(result)
                result["id"] = website_id
                result["saved_to_db"] = True
            except Exception as db_error:
                print(f"⚠️ Ошибка сохранения в БД: {db_error}")
                result["saved_to_db"] = False
                result["db_error"] = str(db_error)
        else:
            result["saved_to_db"] = False
        
        # Этап 5: Завершение
        analysis_tasks[task_id]["progress"] = 100
        analysis_tasks[task_id]["status"] = "completed"
        analysis_tasks[task_id]["result"] = result
        analysis_tasks[task_id]["completed_at"] = asyncio.get_event_loop().time()
        
        print(f"✅ Анализ завершен для {url}")
        
    except Exception as e:
        print(f"❌ Ошибка в задаче анализа {task_id}: {e}")
        analysis_tasks[task_id]["status"] = "error"
        analysis_tasks[task_id]["error"] = str(e)
        analysis_tasks[task_id]["progress"] = 0

@app.get("/api/websites")
async def get_websites(limit: int = 20, offset: int = 0):
    """Получить список всех анализов"""
    try:
        websites = get_all_websites(limit, offset)
        return {
            "status": "success",
            "count": len(websites),
            "websites": websites
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка получения данных: {str(e)}")

@app.get("/api/websites/{website_id}")
async def get_website(website_id: int):
    """Получить анализ по ID"""
    website = get_website_by_id(website_id)
    if not website:
        raise HTTPException(status_code=404, detail="Анализ не найден")
    
    return {
        "status": "success",
        "data": website
    }

@app.delete("/api/websites/{website_id}")
async def delete_website_endpoint(website_id: int):
    """Удалить анализ"""
    success = delete_website(website_id)
    if not success:
        raise HTTPException(status_code=404, detail="Анализ не найден")
    
    return {
        "status": "success",
        "message": "Анализ удален"
    }

@app.get("/api/statistics")
async def get_stats():
    """Получить статистику"""
    try:
        stats = get_statistics()
        return {
            "status": "success",
            "data": stats
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка получения статистики: {str(e)}")

@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Middleware для логирования запросов"""
    response = await call_next(request)
    print(f"{request.method} {request.url.path} - {response.status_code}")
    return response

if __name__ == "__main__":
    import uvicorn
    
    print("\n" + "="*50)
    print("🚀 ЗАПУСК СЕРВЕРА WEBSITE ANALYZER")
    print("="*50)
    print("📡 Адреса сервера:")
    print("   - http://127.0.0.1:8000")
    print("   - http://localhost:8000")
    print("\n📚 API Endpoints:")
    print("   - / - Главная страница")
    print("   - /api - Список API эндпоинтов")
    print("   - /api/health - Проверка состояния")
    print("   - /api/analyze - Анализ сайта (POST)")
    print("   - /api/websites - Список анализов")
    print("   - /api/statistics - Статистика")
    print("="*50 + "\n")
    
    uvicorn.run(
        app,
        host="127.0.0.1",
        port=8000,
        reload=True,
        log_level="info"
    )