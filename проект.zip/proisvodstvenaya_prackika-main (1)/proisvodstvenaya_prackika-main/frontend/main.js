// frontend/main.js
const API_BASE_URL = window.location.origin === 'http://127.0.0.1:8080' || 
                     window.location.origin === 'http://localhost:8080'
    ? 'http://127.0.0.1:8000/api'
    : '/api';

console.log('🚀 API настроен на:', API_BASE_URL);
console.log('🌐 Текущий origin:', window.location.origin);

let currentTaskId = null;
let progressInterval = null;

// Утилиты
function showNotification(message, type = 'info') {
    const colors = {
        success: 'bg-green-100 text-green-800 border-green-300',
        error: 'bg-red-100 text-red-800 border-red-300',
        warning: 'bg-yellow-100 text-yellow-800 border-yellow-300',
        info: 'bg-blue-100 text-blue-800 border-blue-300'
    };
    
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 px-4 py-3 rounded-lg border ${colors[type]} z-50 transition-all duration-300 shadow-lg max-w-md`;
    notification.innerHTML = `
        <div class="flex items-center">
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : type === 'warning' ? 'exclamation-triangle' : 'info-circle'} mr-3"></i>
            <div>
                <div class="font-medium">${type === 'error' ? 'Ошибка' : type === 'success' ? 'Успешно' : type === 'warning' ? 'Внимание' : 'Информация'}</div>
                <div class="text-sm mt-1">${message}</div>
            </div>
            <button onclick="this.parentElement.parentElement.remove()" class="ml-auto text-gray-500 hover:text-gray-700">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 300);
    }, 5000);
}

// Проверка состояния сервера
async function checkServerStatus() {
    try {
        console.log('🔍 Проверяю сервер по адресу:', `${API_BASE_URL}/health`);
        const response = await fetch(`${API_BASE_URL}/health`);
        
        if (response.ok) {
            const data = await response.json();
            console.log('✅ Сервер активен:', data);
            const statusEl = document.getElementById('server-status');
            if (statusEl) {
                statusEl.innerHTML = `<i class="fas fa-circle mr-1"></i> Сервер активен`;
                statusEl.className = 'px-3 py-1 rounded-full bg-green-100 text-green-800';
            }
            return true;
        } else {
            throw new Error(`Статус: ${response.status}`);
        }
    } catch (error) {
        console.error('❌ Ошибка проверки сервера:', error);
        const statusEl = document.getElementById('server-status');
        if (statusEl) {
            statusEl.innerHTML = `<i class="fas fa-circle mr-1"></i> Сервер недоступен`;
            statusEl.className = 'px-3 py-1 rounded-full bg-red-100 text-red-800';
        }
        return false;
    }
}

// Анализ сайта с улучшенной обработкой
async function analyzeWebsite() {
    const urlInput = document.getElementById('analyze-url');
    const url = urlInput.value.trim();
    
    if (!url) {
        showNotification('Введите URL сайта', 'warning');
        urlInput.focus();
        return;
    }
    
    // Базовая валидация URL
    try {
        new URL(url);
    } catch {
        showNotification('Введите корректный URL (например: https://example.com)', 'error');
        urlInput.focus();
        return;
    }
    
    const analyzeBtn = document.getElementById('analyze-btn');
    const progressContainer = document.getElementById('progress-container');
    const resultContainer = document.getElementById('result-container');
    
    // Сбрасываем предыдущие результаты
    if (progressInterval) {
        clearInterval(progressInterval);
    }
    if (currentTaskId) {
        currentTaskId = null;
    }
    
    // Показываем прогресс
    analyzeBtn.disabled = true;
    analyzeBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Анализ...';
    progressContainer.classList.remove('hidden');
    resultContainer.classList.add('hidden');
    
    // Анимация прогресса
    let fakeProgress = 0;
    progressInterval = setInterval(() => {
        fakeProgress += 2;
        if (fakeProgress > 90) fakeProgress = 90;
        updateProgressUI(fakeProgress, 'Ожидание ответа от сервера...');
    }, 300);
    
    try {
        console.log('📤 Отправляю запрос на:', `${API_BASE_URL}/analyze`);
        console.log('📦 Данные:', { url: url });
        
        // Отправляем запрос на анализ
        const response = await fetch(`${API_BASE_URL}/analyze`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({ url: url })
        });
        
        console.log('📥 Получен ответ:', response.status, response.statusText);
        
        const data = await response.json();
        console.log('📊 Данные ответа:', data);
        
        if (!response.ok) {
            throw new Error(data.detail || `Ошибка сервера: ${response.status}`);
        }
        
        clearInterval(progressInterval);
        
        if (data.task_id) {
            currentTaskId = data.task_id;
            console.log('✅ Задача создана, ID:', currentTaskId);
            showNotification('Анализ начат. Ожидайте результатов...', 'info');
            await trackAnalysisProgress(currentTaskId);
        } else {
            throw new Error('Не получен ID задачи');
        }
        
    } catch (error) {
        console.error('❌ Ошибка при анализе:', error);
        clearInterval(progressInterval);
        showNotification(`Ошибка запуска анализа: ${error.message}`, 'error');
        
        // Сбрасываем UI
        resetAnalysisUI();
    }
}

// Отслеживание прогресса анализа
async function trackAnalysisProgress(taskId) {
    const maxAttempts = 60; // 60 попыток = 30 секунд
    let attempts = 0;
    
    const checkProgress = async () => {
        attempts++;
        
        if (attempts > maxAttempts) {
            showNotification('Таймаут анализа. Попробуйте еще раз.', 'error');
            resetAnalysisUI();
            return;
        }
        
        try {
            const statusResponse = await fetch(`${API_BASE_URL}/analysis/${taskId}/status`);
            
            if (!statusResponse.ok) {
                throw new Error('Не удалось получить статус');
            }
            
            const statusData = await statusResponse.json();
            
            // Обновляем прогресс
            updateProgressUI(statusData.progress, getProgressMessage(statusData.progress));
            
            if (statusData.status === 'completed') {
                // Получаем результат
                const resultResponse = await fetch(`${API_BASE_URL}/analysis/${taskId}/result`);
                const resultData = await resultResponse.json();
                
                if (resultResponse.ok) {
                    showResult(resultData.data);
                    showNotification('Анализ успешно завершен!', 'success');
                } else {
                    throw new Error(resultData.detail || 'Ошибка получения результата');
                }
                
                resetAnalysisUI();
                return;
            }
            
            if (statusData.status === 'error') {
                throw new Error(statusData.error || 'Ошибка анализа');
            }
            
            // Продолжаем проверку через 0.5 секунд
            setTimeout(checkProgress, 500);
            
        } catch (error) {
            console.error('Ошибка отслеживания:', error);
            
            if (attempts <= maxAttempts) {
                setTimeout(checkProgress, 1000);
            } else {
                showNotification('Анализ прерван. Проверьте доступность сайта.', 'error');
                resetAnalysisUI();
            }
        }
    };
    
    // Начинаем отслеживание
    await checkProgress();
}

// Обновление UI прогресса
function updateProgressUI(progress, message) {
    const progressBar = document.getElementById('progress-bar');
    const progressPercent = document.getElementById('progress-percent');
    const progressText = document.getElementById('progress-text');
    
    if (progressBar) progressBar.style.width = `${progress}%`;
    if (progressPercent) progressPercent.textContent = `${Math.round(progress)}%`;
    if (progressText) progressText.textContent = message;
}

function getProgressMessage(progress) {
    if (progress < 20) return 'Подготовка к анализу...';
    if (progress < 40) return 'Проверка доступности сайта...';
    if (progress < 60) return 'Анализ производительности...';
    if (progress < 80) return 'Проверка SEO-оптимизации...';
    return 'Формирование отчета...';
}

// Сброс UI анализа
function resetAnalysisUI() {
    const analyzeBtn = document.getElementById('analyze-btn');
    const progressContainer = document.getElementById('progress-container');
    
    if (analyzeBtn) {
        analyzeBtn.disabled = false;
        analyzeBtn.innerHTML = '<i class="fas fa-play mr-2"></i> Анализировать';
    }
    
    if (progressContainer) {
        progressContainer.classList.add('hidden');
    }
    
    if (progressInterval) {
        clearInterval(progressInterval);
        progressInterval = null;
    }
    
    currentTaskId = null;
}

// Показать результаты анализа
function showResult(data) {
    const resultContainer = document.getElementById('result-container');
    
    if (!resultContainer) return;
    
    // Проверяем наличие ошибки
    if (data.error) {
        resultContainer.innerHTML = `
            <div class="bg-red-50 border border-red-200 rounded-xl p-6">
                <div class="flex items-start">
                    <i class="fas fa-exclamation-triangle text-red-500 text-2xl mr-3 mt-1"></i>
                    <div>
                        <h4 class="text-lg font-bold text-red-800 mb-2">Ошибка анализа</h4>
                        <p class="text-red-700 mb-3">${data.error}</p>
                        <p class="text-red-600 text-sm">
                            Проверьте, что сайт доступен и URL указан правильно.
                        </p>
                    </div>
                </div>
            </div>
        `;
        resultContainer.classList.remove('hidden');
        return;
    }
    
    // Определяем цвет статуса
    const score = data.overall_score || 0;
    let statusColor = 'green';
    let statusText = 'Отлично';
    
    if (score >= 80) {
        statusColor = 'green';
        statusText = 'Отлично';
    } else if (score >= 60) {
        statusColor = 'yellow';
        statusText = 'Хорошо';
    } else if (score >= 40) {
        statusColor = 'orange';
        statusText = 'Удовлетворительно';
    } else {
        statusColor = 'red';
        statusText = 'Требует улучшений';
    }
    
    // Форматируем данные
    const createdAt = data.created_at ? new Date(data.created_at).toLocaleString('ru-RU') : 'Только что';
    const recommendations = data.recommendations ? 
        data.recommendations.split('; ').map(rec => 
            `<li class="flex items-start mb-2">
                <i class="fas fa-lightbulb text-yellow-500 mr-2 mt-1"></i>
                <span>${rec}</span>
            </li>`
        ).join('') : 
        '<li class="text-gray-500">Рекомендации не требуются</li>';
    
    // Генерируем HTML
    resultContainer.innerHTML = `
        <div class="bg-white rounded-xl shadow-lg border border-${statusColor}-200 overflow-hidden">
            <!-- Заголовок -->
            <div class="bg-${statusColor}-50 px-6 py-4 border-b border-${statusColor}-200">
                <div class="flex flex-col md:flex-row md:items-center justify-between">
                    <div class="mb-3 md:mb-0">
                        <h4 class="text-xl font-bold text-gray-800 truncate">${data.title || data.url}</h4>
                        <p class="text-gray-600 text-sm truncate">${data.url}</p>
                    </div>
                    <div class="text-center md:text-right">
                        <div class="text-3xl font-bold text-${statusColor}-600">${score}/100</div>
                        <div class="text-sm text-${statusColor}-600">${statusText}</div>
                    </div>
                </div>
            </div>
            
            <div class="p-6">
                <!-- Основные метрики -->
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div class="bg-gray-50 p-4 rounded-lg text-center">
                        <div class="text-sm text-gray-600 mb-1">Производительность</div>
                        <div class="text-2xl font-bold">${data.performance_score || 0}</div>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-lg text-center">
                        <div class="text-sm text-gray-600 mb-1">SEO</div>
                        <div class="text-2xl font-bold">${data.seo_score || 0}</div>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-lg text-center">
                        <div class="text-sm text-gray-600 mb-1">Безопасность</div>
                        <div class="text-2xl font-bold">${data.security_score || 0}</div>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-lg text-center">
                        <div class="text-sm text-gray-600 mb-1">Доступность</div>
                        <div class="text-2xl font-bold">${data.accessibility_score || 0}</div>
                    </div>
                </div>
                
                <!-- Детальная информация -->
                <div class="grid md:grid-cols-2 gap-6 mb-6">
                    <!-- Техническая информация -->
                    <div>
                        <h5 class="font-bold text-gray-700 mb-3 flex items-center">
                            <i class="fas fa-cogs mr-2 text-blue-500"></i>
                            Техническая информация
                        </h5>
                        <div class="space-y-2">
                            <div class="flex justify-between">
                                <span class="text-gray-600">Домен:</span>
                                <span class="font-medium">${data.domain}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Статус код:</span>
                                <span class="${data.status_code === 200 ? 'text-green-600' : 'text-red-600'} font-medium">
                                    ${data.status_code || 'N/A'}
                                </span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">SSL:</span>
                                <span>${data.has_ssl ? '✅ Установлен' : '❌ Отсутствует'}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Время загрузки:</span>
                                <span>${data.response_time_ms || 0} мс</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Размер страницы:</span>
                                <span>${Math.round(data.page_size_kb || 0)} KB</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- SEO статистика -->
                    <div>
                        <h5 class="font-bold text-gray-700 mb-3 flex items-center">
                            <i class="fas fa-chart-line mr-2 text-green-500"></i>
                            SEO статистика
                        </h5>
                        <div class="space-y-2">
                            <div class="flex justify-between">
                                <span class="text-gray-600">Заголовков H1:</span>
                                <span class="${data.h1_count === 1 ? 'text-green-600' : data.h1_count === 0 ? 'text-red-600' : 'text-orange-600'} font-medium">
                                    ${data.h1_count || 0}
                                </span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Заголовков H2:</span>
                                <span>${data.h2_count || 0}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Изображений без alt:</span>
                                <span class="${data.images_without_alt === 0 ? 'text-green-600' : 'text-red-600'} font-medium">
                                    ${data.images_without_alt || 0}
                                </span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Слов на странице:</span>
                                <span>${data.word_count || 0}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Внутренних ссылок:</span>
                                <span>${data.internal_links || 0}</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Рекомендации -->
                <div class="mb-4">
                    <h5 class="font-bold text-gray-700 mb-3 flex items-center">
                        <i class="fas fa-lightbulb mr-2 text-yellow-500"></i>
                        Рекомендации по улучшению
                    </h5>
                    <ul class="list-none pl-0 bg-gray-50 p-4 rounded-lg">
                        ${recommendations}
                    </ul>
                </div>
                
                <!-- Информация об анализе -->
                <div class="text-sm text-gray-500 pt-4 border-t flex flex-wrap items-center justify-between">
                    <div>
                        <i class="fas fa-clock mr-1"></i> Анализ выполнен: ${createdAt}
                    </div>
                    <div class="mt-2 md:mt-0">
                        ${data.id ? `<span class="bg-gray-100 px-2 py-1 rounded">ID: ${data.id}</span>` : ''}
                        ${data.saved_to_db === false ? '<span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded ml-2">Не сохранено в БД</span>' : ''}
                    </div>
                </div>
            </div>
        </div>
    `;
    
    resultContainer.classList.remove('hidden');
    
    // Прокручиваем к результатам
    resultContainer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// Загрузка истории анализов
async function loadHistory() {
    const historyContainer = document.getElementById('history-container');
    if (!historyContainer) return;
    
    historyContainer.innerHTML = `
        <div class="text-center py-12">
            <i class="fas fa-spinner fa-spin text-gray-300 text-5xl mb-4"></i>
            <p class="text-gray-500">Загрузка истории...</p>
        </div>
    `;
    
    try {
        const response = await fetch(`${API_BASE_URL}/websites?limit=10`);
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.detail || 'Ошибка загрузки');
        }
        
        const websites = data.websites || [];
        
        if (websites.length === 0) {
            historyContainer.innerHTML = `
                <div class="text-center py-12">
                    <i class="fas fa-inbox text-gray-300 text-5xl mb-4"></i>
                    <h4 class="text-lg font-medium text-gray-700 mb-2">История анализов пуста</h4>
                    <p class="text-gray-500">Проведите первый анализ сайта</p>
                </div>
            `;
            return;
        }
        
        let html = '<div class="space-y-4">';
        
        websites.forEach(website => {
            const score = website.overall_score || 0;
            let statusColor = 'green';
            
            if (score >= 80) statusColor = 'green';
            else if (score >= 60) statusColor = 'yellow';
            else if (score >= 40) statusColor = 'orange';
            else statusColor = 'red';
            
            const date = website.created_at ? new Date(website.created_at).toLocaleDateString('ru-RU') : 'Неизвестно';
            
            html += `
                <div class="result-card p-4 cursor-pointer hover:shadow-md transition-shadow" onclick="showWebsiteDetails(${website.id})">
                    <div class="flex justify-between items-start">
                        <div class="flex-1 min-w-0">
                            <div class="font-medium text-gray-800 truncate">${website.title || website.url}</div>
                            <div class="text-sm text-gray-600 truncate">${website.url}</div>
                            <div class="text-xs text-gray-500 mt-1">
                                <i class="fas fa-calendar mr-1"></i>${date}
                            </div>
                        </div>
                        <div class="ml-4 flex-shrink-0">
                            <div class="score-badge ${statusColor} px-3 py-1">
                                ${score}
                            </div>
                        </div>
                    </div>
                    <div class="flex flex-wrap gap-3 mt-3 text-sm">
                        <span class="bg-gray-100 px-2 py-1 rounded"><i class="fas fa-tachometer-alt mr-1"></i>${website.performance_score || 0}</span>
                        <span class="bg-gray-100 px-2 py-1 rounded"><i class="fas fa-search mr-1"></i>${website.seo_score || 0}</span>
                        <span class="bg-gray-100 px-2 py-1 rounded"><i class="fas fa-shield-alt mr-1"></i>${website.security_score || website.best_practices_score || 0}</span>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        historyContainer.innerHTML = html;
        
    } catch (error) {
        console.error('Ошибка загрузки истории:', error);
        historyContainer.innerHTML = `
            <div class="text-center py-12">
                <i class="fas fa-exclamation-triangle text-red-300 text-5xl mb-4"></i>
                <p class="text-red-500">Ошибка загрузки истории: ${error.message}</p>
                <button onclick="loadHistory()" class="mt-4 px-4 py-2 bg-gray-100 rounded hover:bg-gray-200">
                    <i class="fas fa-redo mr-2"></i>Повторить
                </button>
            </div>
        `;
    }
}

// Загрузка статистики
async function loadStatistics() {
    const statsContainer = document.getElementById('stats-container');
    if (!statsContainer) return;
    
    try {
        const response = await fetch(`${API_BASE_URL}/statistics`);
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.detail || 'Ошибка загрузки');
        }
        
        const stats = data.data || {};
        
        statsContainer.innerHTML = `
            <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="bg-white p-6 rounded-xl shadow text-center">
                    <div class="text-3xl font-bold text-blue-600 mb-2">${stats.total || 0}</div>
                    <div class="text-gray-600">Всего анализов</div>
                </div>
                <div class="bg-white p-6 rounded-xl shadow text-center">
                    <div class="text-3xl font-bold text-green-600 mb-2">${stats.avg_overall || 0}</div>
                    <div class="text-gray-600">Средняя оценка</div>
                </div>
                <div class="bg-white p-6 rounded-xl shadow text-center">
                    <div class="text-3xl font-bold text-yellow-600 mb-2">${(stats.good || 0) + (stats.excellent || 0)}</div>
                    <div class="text-gray-600">Хорошие сайты</div>
                </div>
                <div class="bg-white p-6 rounded-xl shadow text-center">
                    <div class="text-3xl font-bold text-red-600 mb-2">${(stats.poor || 0) + (stats.bad || 0)}</div>
                    <div class="text-gray-600">Требуют оптимизации</div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-xl shadow">
                <h5 class="font-bold text-gray-700 mb-4">Распределение по оценкам</h5>
                <div class="space-y-4">
                    ${generateProgressBar('Отлично (80-100)', stats.excellent || 0, stats.total || 1, 'bg-green-600')}
                    ${generateProgressBar('Хорошо (60-79)', stats.good || 0, stats.total || 1, 'bg-yellow-600')}
                    ${generateProgressBar('Удовлетворительно (40-59)', stats.poor || 0, stats.total || 1, 'bg-orange-600')}
                    ${generateProgressBar('Плохо (0-39)', stats.bad || 0, stats.total || 1, 'bg-red-600')}
                </div>
            </div>
        `;
        
    } catch (error) {
        console.error('Ошибка загрузки статистики:', error);
        statsContainer.innerHTML = `
            <div class="text-center py-12">
                <i class="fas fa-exclamation-triangle text-red-300 text-5xl mb-4"></i>
                <p class="text-red-500">Ошибка загрузки статистики: ${error.message}</p>
            </div>
        `;
    }
}

function generateProgressBar(label, value, total, colorClass) {
    const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
    return `
        <div>
            <div class="flex justify-between mb-1">
                <span class="text-gray-600">${label}</span>
                <span class="font-medium">${value} (${percentage}%)</span>
            </div>
            <div class="w-full bg-gray-200 rounded-full h-2">
                <div class="${colorClass} h-2 rounded-full" style="width: ${percentage}%"></div>
            </div>
        </div>
    `;
}

// Показать детали сайта
async function showWebsiteDetails(websiteId) {
    try {
        const response = await fetch(`${API_BASE_URL}/websites/${websiteId}`);
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.detail || 'Ошибка загрузки');
        }
        
        const website = data.data;
        
        // Создаем модальное окно
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4';
        modal.innerHTML = `
            <div class="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden">
                <div class="sticky top-0 bg-white border-b px-6 py-4 flex justify-between items-center">
                    <h3 class="text-xl font-bold text-gray-800 truncate">${website.title || website.url}</h3>
                    <button onclick="this.closest('.fixed').remove()" class="text-gray-500 hover:text-gray-700 text-2xl">
                        &times;
                    </button>
                </div>
                <div class="p-6 overflow-y-auto max-h-[calc(90vh-80px)]">
                    <div class="space-y-6">
                        <div class="grid md:grid-cols-2 gap-4">
                            <div>
                                <h5 class="font-bold text-gray-700 mb-2">Основная информация</h5>
                                <div class="space-y-2 text-sm">
                                    <p><strong class="text-gray-600">URL:</strong> <span class="break-all">${website.url}</span></p>
                                    <p><strong class="text-gray-600">Домен:</strong> ${website.domain}</p>
                                    <p><strong class="text-gray-600">Статус код:</strong> 
                                        <span class="${website.status_code === 200 ? 'text-green-600' : 'text-red-600'}">
                                            ${website.status_code || 'N/A'}
                                        </span>
                                    </p>
                                    <p><strong class="text-gray-600">Время анализа:</strong> 
                                        ${website.created_at ? new Date(website.created_at).toLocaleString('ru-RU') : 'Неизвестно'}
                                    </p>
                                </div>
                            </div>
                            <div>
                                <h5 class="font-bold text-gray-700 mb-2">Оценки</h5>
                                <div class="space-y-2 text-sm">
                                    <p><strong class="text-gray-600">Общая оценка:</strong> ${website.overall_score || 0}/100</p>
                                    <p><strong class="text-gray-600">Производительность:</strong> ${website.performance_score || 0}/100</p>
                                    <p><strong class="text-gray-600">SEO:</strong> ${website.seo_score || 0}/100</p>
                                    <p><strong class="text-gray-600">Безопасность:</strong> ${website.security_score || website.best_practices_score || 0}/100</p>
                                </div>
                            </div>
                        </div>
                        
                        <div>
                            <h5 class="font-bold text-gray-700 mb-2">Рекомендации</h5>
                            <p class="text-gray-700 bg-gray-50 p-4 rounded-lg">${website.recommendations || 'Рекомендации не требуются'}</p>
                        </div>
                        
                        <div class="flex flex-wrap gap-4 pt-4 border-t">
                            <button onclick="deleteWebsite(${website.id})" 
                                    class="px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition">
                                <i class="fas fa-trash mr-2"></i>Удалить анализ
                            </button>
                            <button onclick="generateReport(${website.id})" 
                                    class="px-4 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition">
                                <i class="fas fa-file-pdf mr-2"></i>Создать отчет
                            </button>
                            <button onclick="this.closest('.fixed').remove()" 
                                    class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition ml-auto">
                                Закрыть
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
    } catch (error) {
        showNotification(`Ошибка загрузки деталей: ${error.message}`, 'error');
    }
}

// Удалить сайт
async function deleteWebsite(websiteId) {
    if (!confirm('Вы уверены, что хотите удалить этот анализ?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/websites/${websiteId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.detail || 'Ошибка удаления');
        }
        
        showNotification('Анализ успешно удален', 'success');
        
        // Закрываем модальное окно
        const modal = document.querySelector('.fixed.bg-black');
        if (modal) modal.remove();
        
        // Обновляем историю
        if (document.getElementById('history-tab').classList.contains('active')) {
            loadHistory();
        }
        
    } catch (error) {
        showNotification(`Ошибка удаления: ${error.message}`, 'error');
    }
}

// Создать отчет
function generateReport(websiteId) {
    showNotification('Функция создания отчета в разработке', 'info');
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    console.log('Website Analyzer загружен');
    console.log('API Base URL:', API_BASE_URL);
    
    // Проверяем статус сервера
    checkServerStatus();
    
    // Обработка нажатия Enter в поле ввода URL
    const urlInput = document.getElementById('analyze-url');
    if (urlInput) {
        urlInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                analyzeWebsite();
            }
        });
        
        // Автофокус на поле ввода
        urlInput.focus();
    }
    
    // Обработчики для вкладок
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const tabId = btn.getAttribute('data-tab');
            
            // Обновляем активные кнопки
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            // Показываем активную вкладку
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            document.getElementById(`${tabId}-tab`).classList.add('active');
            
            // Загружаем данные для вкладки
            if (tabId === 'history') {
                loadHistory();
            } else if (tabId === 'statistics') {
                loadStatistics();
            }
        });
    });
    
    // Обновляем статус сервера каждые 30 секунд
    setInterval(checkServerStatus, 30000);
    
    // Тестовый анализ популярных сайтов
    const testUrls = [
        'https://google.com',
        'https://yandex.ru',
        'https://github.com'
    ];
    
    // Можно добавить кнопки для быстрого теста
    const testContainer = document.createElement('div');
    testContainer.className = 'mt-4 text-sm';
    testContainer.innerHTML = `
        <div class="text-gray-600 mb-2">Быстрый тест:</div>
        <div class="flex flex-wrap gap-2">
            ${testUrls.map(url => `
                <button onclick="document.getElementById('analyze-url').value='${url}'; analyzeWebsite();" 
                        class="px-3 py-1 bg-gray-100 hover:bg-gray-200 rounded text-sm">
                    ${new URL(url).hostname}
                </button>
            `).join('')}
        </div>
    `;
    
    const analyzeTab = document.getElementById('analyze-tab');
    if (analyzeTab) {
        const form = analyzeTab.querySelector('.space-y-6');
        if (form) {
            form.appendChild(testContainer);
        }
    }
});

// Экспортируем функции для использования в HTML
window.analyzeWebsite = analyzeWebsite;
window.loadHistory = loadHistory;
window.loadStatistics = loadStatistics;
window.showWebsiteDetails = showWebsiteDetails;
window.deleteWebsite = deleteWebsite;
window.generateReport = generateReport;