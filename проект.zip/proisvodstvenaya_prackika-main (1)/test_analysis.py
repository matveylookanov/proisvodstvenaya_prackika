import asyncio
import sys
import os

sys.path.append(os.path.dirname(__file__))

from website_analyzer import WebsiteAnalyzer

async def test_analysis():
    """Тестовая функция для проверки анализа"""
    analyzer = WebsiteAnalyzer()
    
    test_urls = [
        "https://google.com",
        "https://yandex.ru"
    ]
    
    for url in test_urls:
        print(f"\n🔍 Тестируем: {url}")
        try:
            result = await analyzer.analyze(url)
            
            if result.get("error"):
                print(f"❌ Ошибка: {result['error']}")
            else:
                print(f"✅ Успешно!")
                print(f"   Заголовок: {result.get('title', 'Нет')}")
                print(f"   Статус код: {result.get('status_code')}")
                print(f"   Оценка: {result.get('overall_score')}/100")
                print(f"   Время ответа: {result.get('response_time_ms')}мс")
                
        except Exception as e:
            print(f"❌ Исключение: {e}")

if __name__ == "__main__":
    print("🧪 Тестирование анализа сайтов...")
    asyncio.run(test_analysis())